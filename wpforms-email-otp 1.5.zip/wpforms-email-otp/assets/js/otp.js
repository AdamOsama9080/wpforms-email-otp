/**
 * WPForms Email-OTP frontend logic
 * – disables submit until OTP verified
 * – handles send + check OTP
 */
jQuery(function ($) {
    //--------------------------------------------------------------
    // 0️⃣  Disable every WPForms submit button on page-load
    //--------------------------------------------------------------
    $("form.wpforms-form").each(function () {
        $(this).find('button[type="submit"]').prop("disabled", true);
    });

    //--------------------------------------------------------------
    // 1️⃣  SEND OTP
    //--------------------------------------------------------------
    $(document).on("click", ".send-otp-btn", function () {
        const $btn  = $(this);
        const $form = $btn.closest("form");
        const email = $form.find("input[type=email]").val();

        if (!email) {
            alert("Please enter a valid email");
            return;
        }

        $btn.prop("disabled", true).text("Sending…");

        $.post(wpformsOtp.ajaxurl, {
            action: "send_wpforms_otp",
            email:  email,
            nonce:  wpformsOtp.nonce
        }).done(function (response) {

            if (response.success) {
                alert("OTP sent!");
                // Show the OTP input + Check button
                $form.find(".otp-field").show();
                $form.find(".otp-field .check-otp-btn").show();
            } else {
                alert(response.data.message || "Failed to send OTP");
            }

        }).always(function () {
            $btn.prop("disabled", false).text("Send OTP");
        });
    });

    //--------------------------------------------------------------
    // 2️⃣  CHECK OTP
    //--------------------------------------------------------------
    $(document).on("click", ".check-otp-btn", function () {
        const $btn  = $(this);
        const $form = $btn.closest("form");
        const email = $form.find("input[type=email]").val();
        const otp   = $form.find(".otp-input").val();

        if (!otp) {
            alert("Please enter the OTP.");
            return;
        }

        $btn.prop("disabled", true).text("Checking…");

        $.post(wpformsOtp.ajaxurl, {
            action: "check_wpforms_otp",
            email:  email,
            otp:    otp,
            nonce:  wpformsOtp.nonce
        }).done(function (response) {

            // Remove any previous status message
            $form.find(".otp-status").remove();

            if (response.success) {
                //--------------------------------------------------
                // ✅ CORRECT OTP
                //--------------------------------------------------
                // Show success message
                $('<div class="otp-status" style="color:#2d8a3c;margin:8px 0;">OTP is correct – you can complete registration ✔</div>')
                    .insertAfter($btn);

                // Remove OTP field + button block
                $form.find(".otp-field").remove();

                // Enable the submit button
                $form.find('button[type="submit"]').prop("disabled", false);

            } else {
                //--------------------------------------------------
                // ❌ WRONG OTP
                //--------------------------------------------------
                $('<div class="otp-status" style="color:#d63638;margin:8px 0;">OTP is wrong – please try again.</div>')
                    .insertAfter($btn);

                // Allow another try
                $btn.prop("disabled", false).text("Check OTP");
                $form.find('button[type="submit"]').prop("disabled", true);
            }

        }).fail(function () {
            alert("Network error – please try again.");
            $btn.prop("disabled", false).text("Check OTP");
        });
    });
});
