<?php
/*
Plugin Name: WPForms Email OTP Verification
Description: Adds email OTP verification to WPForms forms.
Version: 1.0
Author: Adam Osama
*/

if (!defined('ABSPATH')) exit;

define('WPFORMS_EMAIL_OTP_VERSION', '1.0');
define('WPFORMS_EMAIL_OTP_DIR', plugin_dir_path(__FILE__));
define('WPFORMS_EMAIL_OTP_URL', plugin_dir_url(__FILE__));

require_once WPFORMS_EMAIL_OTP_DIR . 'includes/otp-handler.php';
require_once WPFORMS_EMAIL_OTP_DIR . 'includes/email-sender.php';

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script('wpforms-otp-js', WPFORMS_EMAIL_OTP_URL . 'assets/js/otp.js', ['jquery'], null, true);
    wp_enqueue_style('wpforms-otp-css', WPFORMS_EMAIL_OTP_URL . 'assets/css/otp.css');

    wp_localize_script('wpforms-otp-js', 'wpformsOtp', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('wpforms_email_otp_nonce'),
    ]);
});

add_action('wp_ajax_send_wpforms_otp', 'wpforms_send_otp_ajax');
add_action('wp_ajax_nopriv_send_wpforms_otp', 'wpforms_send_otp_ajax');
function wpforms_send_otp_ajax() {
    check_ajax_referer('wpforms_email_otp_nonce', 'nonce');
    $email = sanitize_email($_POST['email']);
    $otp = WPForms_OTP_Handler::generate_otp();
    WPForms_OTP_Handler::store_otp($email, $otp);
    $sent = WPForms_Email_Sender::send_otp($email, $otp);

    if ($sent) {
        wp_send_json_success(['message' => 'OTP sent successfully.']);
    } else {
        wp_send_json_error(['message' => 'Failed to send OTP.']);
    }
}

add_filter('wpforms_process_validate', function ($fields, $entry, $form_data) {
    foreach ($fields as $id => $field) {
        if ($field['type'] === 'email') {
            $email = sanitize_email($field['value']);
            $otp = sanitize_text_field($_POST['wpforms']['otp'] ?? '');
            if (!WPForms_OTP_Handler::verify_otp($email, $otp)) {
                wpforms()->process->errors[$form_data['id']][$id] = 'Invalid or missing OTP code.';
            }
        }
    }
    return $fields;
}, 10, 3);
?>
