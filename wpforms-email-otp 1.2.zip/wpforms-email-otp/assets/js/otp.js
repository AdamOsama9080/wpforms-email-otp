jQuery(function($) {
    $(document).on("click", ".send-otp-btn", function() {
        const $btn = $(this);
        const $form = $btn.closest("form");
        const email = $form.find("input[type=email]").val();
        if (!email) return alert("Please enter a valid email");

        $btn.prop("disabled", true).text("Sending...");
        $.post(wpformsOtp.ajaxurl, {
            action: "send_wpforms_otp",
            email: email,
            nonce: wpformsOtp.nonce
        }, function(response) {
            if (response.success) {
                alert("OTP sent!");
                $form.find(".otp-field").show();
            } else {
                alert(response.data.message);
            }
            $btn.prop("disabled", false).text("Send OTP");
        });
    });
});
